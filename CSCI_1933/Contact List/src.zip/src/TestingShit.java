/**
 * Created by pidap004 on 3/8/16.
 */
public class TestingShit {

    public static void main(String[] args) {
        int h [] = {1,2,3,4,5,6};
        for (int i:h) {
            System.out.println(i);
        }

    }
}
